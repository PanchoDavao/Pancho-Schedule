/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./dist/*.{html,js}"],
  theme: {
    colors: {
      transparent: 'transparent',
      black: '#000',
      white: '#fff',
      color: 'inherit',
      gray: {
        100: '#f7fafc',
        200: '#e5e7eb',
        300: '#d1d5db',
        400:'#9ca3af',
        500: '#6b7280',
        600:'#4b5563',
        700: '#1f2937',
        800:  '#1f2937',
        900: '#1a202c',
      },colors: {
        'blue': '#1fb6ff',
      'purple': '#7e5bef',
      'pink': '#ff49db',
      'orange': '#ff7849',
      'green': '#13ce66',
      'yellow': '#ffc82c',
      'gray-dark': '#273444',
      'gray': '#8492a6',
      'gray-light': '#d3dce6',
    },
    
    fontFamily: {
      sans: ['Graphik', 'sans-serif'],
      serif: ['Merriweather', 'serif'],
    },
    extend: {
      spacing: {
        '8xl': '96rem',
        '9xl': '128rem',
      },
      borderRadius: {
        '4xl': '2rem',
      },
    
    extend: {},
  },
  plugins: ['margin',
    'padding',
    'backgroundColor',],
}
}
}
