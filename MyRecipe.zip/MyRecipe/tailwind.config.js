/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./index.html","./contact.html","./404.html","./about.html","./recipe.html","./single-recipe.html","./tag-template.html","./tags.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}
